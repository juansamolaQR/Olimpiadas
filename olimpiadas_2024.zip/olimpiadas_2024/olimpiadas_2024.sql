-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307:3307
-- Tiempo de generación: 24-08-2024 a las 11:05:34
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `olimpiadas_2024`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `id_usuario` int(11) NOT NULL,
  `id_prod` int(11) NOT NULL,
  `cantidad` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(10) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `con_cifrada` varchar(1000) NOT NULL,
  `verificado` int(1) NOT NULL,
  `permisos` int(1) NOT NULL COMMENT '0-Cliente\r\n1-Administrador'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `email`, `con_cifrada`, `verificado`, `permisos`) VALUES
(1, 'juan carlos', 'juanquipb@gmail.com', '$2y$10$.tvCXzpVuut9FY.R8ws6g.H5.tvgFSvPm/lAYIXAluw6j89RkBk7m', 1, 1),
(2, 'roman rotela', 'romanrotela@gmail.com', '$2y$10$93S05ozldPNqPdZXfRIwKO4RTs6P38oa7inPM2MgJtf9Gu43Vg0eu', 1, 1),
(3, 'hola', 'hola@gmail.com', '$2y$10$JHNmzQkGJxjPlXhQ/ITnjeW35CIIYf05pHfmYXtKt7dJTk9wZc3Cm', 1, 0),
(4, 'ahre123', 'ahre123@gmail.com', '$2y$10$afBAeDF2TqgBLAXBAHI50Ounx6gYRIeEqfUKwP0nExb/Z6tS6komq', 1, 0),
(6, 'ajsdklj', 'hola345@gmail.com', '$2y$10$Ydp2SDPdY8zEsOBZ/EbTeOioZHzQv7d3qz2YroZAcotsPM5BRUQFy', 1, 0),
(7, 'hola trola', 'jeje@gmail.com', '$2y$10$j7VhxgS5Te.tWU3j/wepueQGbibfhpHE28Oq9tHGy7ZBjBMaBArVy', 0, 0),
(8, 'romancito', 'romancito@gmail.com', '$2y$10$dTsd4VumyJZliiQBQYV2DezhVtkivW8FbWTymk4y0Tuh5rKvrJ0BK', 1, 0),
(9, 'Test1', 'test1@gmail.com', '$2y$10$zqNj9/kVnCdD.lsT3T/G7.oUgCcww1V.Ox2tpGFpDsQ4nGs4/O/RG', 0, 0),
(10, 'Test2', 'test2@gmail.com', '$2y$10$qUXMI32YJVUl5nBDXFG6lO4A.MyVL.GiWVvO4n.FJvjgu2t/eCNbe', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_historico`
--

CREATE TABLE `pedidos_historico` (
  `id_pedido` int(100) NOT NULL,
  `id_usuario` int(100) NOT NULL,
  `productos` varchar(200) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `cantidad` varchar(500) NOT NULL,
  `pago` varchar(100) NOT NULL,
  `entrega` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pedidos_historico`
--

INSERT INTO `pedidos_historico` (`id_pedido`, `id_usuario`, `productos`, `total`, `cantidad`, `pago`, `entrega`) VALUES
(4, 8, 'Test2', 244.66, '1', 'Pago', 'Entregado'),
(5, 1, 'Test1,Test2', 255.65, '1,1', 'Pago', 'Entregado'),
(6, 1, 'Test1,Test2,Test3', 1606.64, '1,1,1', 'Pago', 'Entregado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_pendientes`
--

CREATE TABLE `pedidos_pendientes` (
  `id_pedido` int(100) NOT NULL,
  `id_usuario` int(100) NOT NULL,
  `productos` varchar(535) NOT NULL,
  `cantidad` varchar(200) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `pago` int(1) NOT NULL COMMENT '0- No pago\r\n1- Pago',
  `entregado` int(1) NOT NULL COMMENT '0- No entregado\r\n1- Entregado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pedidos_pendientes`
--

INSERT INTO `pedidos_pendientes` (`id_pedido`, `id_usuario`, `productos`, `cantidad`, `total`, `pago`, `entregado`) VALUES
(8, 1, 'test3cambio', '2', 1111.32, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `precio_uni` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `titulo`, `descripcion`, `precio_uni`) VALUES
(1, 'Test1', 'Test1 descripcion', 10.99),
(2, 'Test2', 'Test 2 descripcion', 244.66),
(3, 'test3cambio', 'test3cambio descripcion', 555.66),
(5, 'Test4', 'Test4 descripcion', 199.88),
(9, 'test7', 'test7', 123.12);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD KEY `id_producto` (`id_prod`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos_pendientes`
--
ALTER TABLE `pedidos_pendientes`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pedidos_pendientes`
--
ALTER TABLE `pedidos_pendientes`
  MODIFY `id_pedido` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`id_prod`) REFERENCES `productos` (`id_producto`),
  ADD CONSTRAINT `carrito_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `clientes` (`id`);

--
-- Filtros para la tabla `pedidos_pendientes`
--
ALTER TABLE `pedidos_pendientes`
  ADD CONSTRAINT `pedidos_pendientes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `clientes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
