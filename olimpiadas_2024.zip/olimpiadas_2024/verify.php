<?php
include('modules/connection.php');

if (isset($_GET['code'])) {
    $code = $_GET['code'];
    
    $sql = "UPDATE clientes SET verificado = 1 WHERE MD5(email) = '$code'";
    
    if ($connection->query($sql) === TRUE) {
        echo "Email verificado correctamente.";
    } else {
        echo "Error verificando email: " . $connection->error;
    }
}

$connection->close();
?>