<?php
session_start();
include('connection.php');
$id = $_SESSION['id'];
$getquery = "SELECT
*
FROM `pedidos_pendientes`
WHERE id_usuario = $id";
$resultadoget = mysqli_query($connection,$getquery);
if($resultadoget){
while($row=mysqli_fetch_array($resultadoget))
    {
        echo '
                    <tr>
                    <td class="p-4">
                      <div class="media align-items-center">
                        <div class="media-body">
                          <a href="#" class="d-block text-dark">'.$row['productos'].'</a>
                        </div>
                      </div>
                    </td>
                    <td class="text-right font-weight-semibold align-middle p-4">'.$row['cantidad'].'</td>
                    <td class="align-middle p-4">$'.$row['total'].'</td>';
                if($row['pago'] == 1){
                  echo'<td class="text-right font-weight-semibold align-middle p-4">Pago</td>';
                } else{
                    echo '<td class="text-right font-weight-semibold align-middle p-4">No pago</td>';
                }   
                echo'    <td class="text-center align-middle px-0"><a href="#" onclick="remove('.$row['id_usuario'].','.$row['id_pedido'].')" class="shop-tooltip close float-none text-danger" title="" data-original-title="Remove">×</a></td>
                  </tr>';
    }
} else {
    echo 'Agregue pedidos';
}
                    
?>