<?php
include('connection.php');

$data = $_POST['entrega'];
$get = "SELECT * FROM pedidos_pendientes WHERE id_pedido=$data";
$resultadoGet = mysqli_query($connection,$get);
while($row=mysqli_fetch_array($resultadoGet)){
    $idpedido = $row['id_pedido'];
    $idusuario = $row['id_usuario'];
    $productos = $row['productos'];
    $cantidad = $row['cantidad'];
    $total = $row['total'];
    $insert = "INSERT INTO `pedidos_historico`(`id_pedido`, `id_usuario`, `productos`, `total`, `cantidad`, `pago`, `entrega`) VALUES ('$idpedido','$idusuario','$productos','$total','$cantidad','Pago', 'Entregado')";
    $resultadoInsert = mysqli_query($connection,$insert);
}
$delete = "DELETE FROM `pedidos_pendientes` WHERE id_pedido=$data";
$resultadoDelete = mysqli_query($connection,$delete);

echo mysqli_error($connection);

?>