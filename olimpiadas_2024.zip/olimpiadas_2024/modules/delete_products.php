<?php
include('connection.php');

$data = $_POST['delete'];

$delete = "DELETE FROM `productos` WHERE id_producto=$data";

$resultadoDelete = mysqli_query($connection,$delete);

?>