<?php
session_start();
include('connection.php');
$id = $_SESSION['id'];
$getquery = "SELECT
*
FROM `carrito`
INNER JOIN productos ON id_prod = id_producto
INNER JOIN clientes ON id_usuario = id
WHERE id_usuario = $id";
$resultadoget = mysqli_query($connection,$getquery);
if($resultadoget){
while($row=mysqli_fetch_array($resultadoget))
    {
        $totalproducto = $row['precio_uni'] * $row['cantidad'];
        echo '
                    <tr>
                    <td class="p-4">
                      <div class="media align-items-center">
                        <div class="media-body">
                          <a href="#" class="d-block text-dark">'.$row['titulo'].'</a>
                          <small>
                            <span class="text-muted">'.$row['descripcion'].'</span>
                          </small>
                        </div>
                      </div>
                    </td>
                    <td class="text-right font-weight-semibold align-middle p-4">$'.$row['precio_uni'].'</td>
                    <td class="align-middle p-4">'.$row['cantidad'].'</td>
                    <td class="text-right font-weight-semibold align-middle p-4">$'.$totalproducto.'</td>
                    <td class="text-center align-middle px-0"><a href="#" onclick="remove('.$row['id_usuario'].','.$row['id_prod'].')" class="shop-tooltip close float-none text-danger" title="" data-original-title="Remove">×</a></td>
                  </tr>
        ';
    }
} else {
    echo 'Agregue productos al carrito';
}
                    
?>