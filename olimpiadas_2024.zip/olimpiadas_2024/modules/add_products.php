<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $select = mysqli_query($connection, "SELECT `titulo` FROM `productos` WHERE `titulo` = '".$_POST['nombre']."'") or exit(mysqli_error($connection));
    if(mysqli_num_rows($select)) {
        echo('Producto ya registrado');
    } else if (mysqli_num_rows($select) == 0){
        $titulo = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $sql = "INSERT INTO productos (titulo, descripcion, precio_uni) VALUES ('$titulo', '$descripcion', '$precio')";
    $connection->query($sql);
    echo "OK";
}}
$connection->close();
?>