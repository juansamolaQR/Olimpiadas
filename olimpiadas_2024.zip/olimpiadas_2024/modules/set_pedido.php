<?php
include('connection.php');
$idpedido = $_POST['idpedido'];
$total = $_POST['total'];
$getquery = "SELECT id_prod,
GROUP_CONCAT(productos.titulo ORDER BY productos.titulo ASC) AS concat_prod,
GROUP_CONCAT(carrito.cantidad ORDER BY carrito.cantidad ASC) AS concat_cantidad
 FROM carrito
 INNER JOIN productos on productos.id_producto = id_prod
  WHERE id_usuario = $idpedido";
$resultget = mysqli_query($connection, $getquery);
$productos = '';
$cantidad = '';
while($row=mysqli_fetch_array($resultget)){
    $productos = $row['concat_prod'];
    $cantidad = $row['concat_cantidad'];
}

$insertquery = "INSERT INTO pedidos_pendientes (`id_usuario`, `productos`, `cantidad`, `total`, `pago`, `entregado`) VALUES ('$idpedido', '$productos','$cantidad', '$total', 0, 0)";
$resultinsert = mysqli_query($connection, $insertquery);

$deletequery = "DELETE FROM carrito WHERE id_usuario = $idpedido";
$resultdelete = mysqli_query($connection, $deletequery);

echo mysqli_error($connection);

?>