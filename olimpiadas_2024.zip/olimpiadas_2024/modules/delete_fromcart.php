<?php
include('connection.php');

$data = $_POST['delete'];
$data2 = $_POST['delete2'];

$delete = "DELETE FROM `carrito` WHERE id_prod=$data AND id_usuario=$data2";

$resultadoDelete = mysqli_query($connection,$delete);

echo mysqli_error($resultadoDelete);

?>