<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $select = mysqli_query($connection, "SELECT `email` FROM `clientes` WHERE `email` = '".$_POST['email']."'") or exit(mysqli_error($connection));
    if (mysqli_num_rows($select) == 0){
        echo('Email no encontrado');
    } else if(mysqli_num_rows($select) == 1){
        $email = $_POST['email'];
        $contrasena = $_POST['contrasena'];
        $consulta_usuario = "SELECT * FROM `clientes` WHERE email = '$email'";
        $resultado_usuario = $connection->query($consulta_usuario);
        if ($resultado_usuario->num_rows > 0) {
            $fila = $resultado_usuario->fetch_assoc();
            $id = $fila['id'];
            $nombre = $fila['nombre'];
            $emailbd = $fila['email'];
            $hashedPassword = $fila['con_cifrada'];
            $verificacion = $fila['verificado'];
            $permisos = $fila['permisos'];
            if (password_verify($contrasena, $hashedPassword)) {
                if ($verificacion == 0){
                    echo ('Su usuario no está verificado');
                } else {
                    session_start();
                    $_SESSION["loggedin"] = true;
                    $_SESSION["id"] = $id;
                    $_SESSION["nombre"] = $nombre;
                    $_SESSION["email"] = $emailbd;
                    $_SESSION["permisos"] = $permisos;
                    echo('Sesión iniciada');
                }
            } else{
                echo ('Contrasena incorrecta');
            }
        }
    }
}