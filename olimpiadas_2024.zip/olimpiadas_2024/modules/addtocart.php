<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idproducto = $_POST['idprod'];
    $idusuario = $_POST['idusuario'];
    $select = mysqli_query($connection, "SELECT `id_prod` FROM `carrito` WHERE `id_usuario` = '".$_POST['idusuario']."' AND `id_prod` = '".$_POST['idprod']."'") or exit(mysqli_error($connection));
        if(mysqli_num_rows($select)){
        $sql1 = "UPDATE carrito SET cantidad = cantidad + 1 WHERE id_prod = $idproducto";
        $connection->query($sql1);
        echo (mysqli_error($connection));
        echo "OK";
    } else if (mysqli_num_rows($select) == 0){
    $sql = "INSERT INTO carrito (id_usuario, id_prod, cantidad) VALUES ('$idusuario', '$idproducto', 1)";
    $connection->query($sql);
    echo mysqli_error($connection);
    echo "OK";
    }

}
$connection->close();
?>