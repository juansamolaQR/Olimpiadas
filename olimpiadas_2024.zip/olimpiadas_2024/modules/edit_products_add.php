<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $select = mysqli_query($connection, "SELECT `titulo` FROM `productos` WHERE `titulo` = '".$_POST['nombre']."'") or exit(mysqli_error($connection));
    if(mysqli_num_rows($select)) {
        echo('Producto ya registrado');
    } else if (mysqli_num_rows($select) == 0){
        $id = $_POST['id'];
        $getquery = "SELECT * FROM `productos` WHERE id_producto = $id";
        $resultadoget = mysqli_query($connection,$getquery);
        while($row=mysqli_fetch_array($resultadoget))
        {
        $titulo_bd = $row['titulo'];
        $descripcion_bd = $row['descripcion'];
        $precio_bd = $row['precio_uni'];
        $titulo = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $precio = $_POST['precio'];
        if(isset($titulo) AND isset($descripcion) AND isset($precio)){
            $query1 = "UPDATE productos SET `titulo` = '$titulo', `descripcion` = '$descripcion', `precio_uni` = '$precio' WHERE `id_producto` = $id";
            $connection->query($query1);
            echo 'OK';
        } else if (isset($titulo) AND isset($descripcion)){
            $query2 = "UPDATE productos SET `titulo` = '$titulo', `descripcion` = '$descripcion', `precio_uni` = '$precio_bd' WHERE `id_producto` = $id";
            $connection->query($query2);
            echo 'OK';
        } else if (isset($titulo) AND isset($precio)){
            $query3 = "UPDATE productos SET `titulo` = '$titulo', `descripcion` = '$descripcion_bd', `precio_uni` = '$precio' WHERE `id_producto` = $id";
            $connection->query($query3);
            echo 'OK';
        } else if (isset($precio) AND isset($descripcion)){
            $query4 = "UPDATE productos SET `titulo` = '$titulo_bd', precio_uni = '$precio', `descripcion` = '$descripcion' WHERE `id_producto` = $id";
            $connection->query($query4);
            echo 'OK';
        } else if (isset($titulo)){
            $query5 = "UPDATE productos SET `titulo` = '$titulo', `descripcion` = '$descripcion_bd', `precio_uni` = '$precio_bd'  WHERE `id_producto` = $id";
            $connection->query($query5);
            echo 'OK';
        } else if (isset($descripcion)){
            $query6 = "UPDATE productos SET `titulo` = '$titulo_bd', `descripcion` = '$descripcion', `precio_uni` = '$precio_bd' WHERE `id_producto` = $id";
            $connection->query($query6);
            echo 'OK';
        } else if (isset($precio)){
            $query7 = "UPDATE productos SET `titulo` = '$titulo_bd', `descripcion` = '$descripcion_bd', `precio_uni` = '$precio' WHERE `id_producto` = $id";
            $connection->query($query7);
            echo 'OK';
        } 

}}
}
$connection->close();
?>