<?php
include('connection.php');

$getquery = "SELECT * FROM `pedidos_historico`";

$resultadoget = mysqli_query($connection,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo "<tr>";
        echo "<td>" . $row['id_pedido'] . "</td>";
        echo "<td>" . $row['id_usuario'] . "</td>";
        echo "<td>" . $row['productos'] . "</td>";
        echo "<td>" . $row['cantidad'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        echo "<td>" . $row['pago'] . "</td>";
        echo "<td>" . $row['entrega'] . "</td>";
        echo "</tr>";
    }
    echo '</table>';
?>