<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $select = mysqli_query($connection, "SELECT `email` FROM `clientes` WHERE `email` = '".$_POST['email']."'") or exit(mysqli_error($connection));
    if(mysqli_num_rows($select)) {
        echo('Email en uso');
    } else if (mysqli_num_rows($select) == 0){
    $username = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO clientes (nombre, email, con_cifrada, verificado) VALUES ('$username', '$email', '$password', '0')";
    
    if ($connection->query($sql) === TRUE) {
        $verificationCode = md5($email);
        $verificationLink = "localhost/olimpiadas_2024/verify.php?code=$verificationCode";
        $subject = "Verifique su cuenta";
        $message = "Clickee el siguiente link para verificar su cuenta:\n$verificationLink";
        mail($email, $subject, $message);
        
        echo "Registro completado. Verifique su mail para confirmar.";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}}
$connection->close();
?>