<?php
include('connection.php');

$data = $_POST['delete'];

$delete = "DELETE FROM `pedidos_pendientes` WHERE id_pedido=$data";

$resultadoDelete = mysqli_query($connection,$delete);

echo mysqli_error($resultadoDelete);

?>