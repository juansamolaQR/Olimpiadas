<?php
        $connection = mysqli_connect('127.0.0.1:3307','root','','olimpiadas_2024');
        if ($connection) {
    
         //echo 'Conexión correcta';
    
        };
?>