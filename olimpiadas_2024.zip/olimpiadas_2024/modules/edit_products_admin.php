<?php
include('connection.php');

$id = $_GET['id'];

$getquery = "SELECT * FROM `productos` where id_producto = $id";

$resultadoget = mysqli_query($connection,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo '<input type="text" class="form-control" id="edit_titulo" placeholder="'.$row['titulo'].'">';
        echo '<input type="text" id="edit_descripcion" class="form-control" placeholder="'.$row['descripcion'].'">';
        echo '<input type="number" min="1" step="any" class="form-control" id="edit_precio" placeholder="'.$row['precio_uni'].'">';
    }
    ;
?>