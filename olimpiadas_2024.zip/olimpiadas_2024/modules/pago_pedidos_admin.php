<?php 
include('connection.php');
$pago = $_POST['pago'];
$update = "UPDATE pedidos_pendientes SET pago=1 WHERE id_pedido = $pago";
$resultadoUpdate = mysqli_query($connection, $update);
?>