<?php
include('connection.php');

$getquery = "SELECT * FROM `pedidos_pendientes`";

$resultadoget = mysqli_query($connection,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo "<tr>";
        echo "<td>" . $row['id_pedido'] . "</td>";
        echo "<td>" . $row['id_usuario'] . "</td>";
        echo "<td>" . $row['productos'] . "</td>";
        echo "<td>" . $row['cantidad'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        if ($row['pago'] == 0){
            echo "<td>No pago</td>";
        } else {
            echo "<td>Pago</td>";
        }
        echo "<td>No entregado</td>";
        echo '<td><button class="btn btn-danger" id="delete" onclick="myDelete('.$row['id_pedido'].')"> Eliminar </button> <button class="btn btn-primary" id="pago" onclick="myPago('.$row['id_pedido'].')"> Pago </button> <button class="btn btn-success" id="entregado" onclick="myFinish('.$row['id_pedido'].')"> Entregado </button></td>'; 
        echo "</tr>";
    }
    echo '</table>';
?>