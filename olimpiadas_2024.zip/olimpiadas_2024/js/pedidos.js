$(document).ready(function() {
    $.ajax({
        url     : 'modules/fetch_pedidos.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablepedidos").html(resp);
        },
        error   : function(resp){
        }  
    });
});


function volver(){
    window.location.href = "index.php";
}

function remove(iduser, idpedido){
          $.ajax({
            type:"post",
            url:"modules/delete_frompedidos.php",
            data: { delete : idpedido,
                delete2 : iduser
            },
            success:function(data){
              Swal.fire("¡Eliminado!", "", "success");
              location.reload();
            }
        })
    }

    
   

