$(document).ready(function() {
    $.ajax({
        url     : 'modules/fetch_pedidos_admin.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablepedidos").html(resp);
        },
        error   : function(resp){
        }  
    });
});

$(document).ready(function() {
    $.ajax({
        url     : 'modules/fetch_pedidos_historicos.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablepedidoshistoria").html(resp);
        },
        error   : function(resp){
        }  
    });
});


function myDelete(deleteid){
    Swal.fire({
      title: "¿Está seguro de eliminar este pedido?",
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonText: "Eliminar",
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          type:"post",
          url:"modules/delete_pedidos_admin.php",
          data: { delete : deleteid},
          success:function(data){
            location.reload();
            Swal.fire("¡Eliminado!", "", "success");
          }
      });
      } else if (result.isDenied) {
        Swal.fire("No se eliminó el pedido", "", "info");
      }
    });
  }

  function myFinish(entregaid){
        $.ajax({
          type:"post",
          url:"modules/entregar_pedidos_admin.php",
          data: { entrega : entregaid},
          success:function(data){
            console.log(data);
            location.reload();
          }
      });
    }

  function myPago(pagoid){
    $.ajax({
      type:"post",
      url:"modules/pago_pedidos_admin.php",
      data: { pago : pagoid},
      success:function(data){
        location.reload();
      }
  });
}