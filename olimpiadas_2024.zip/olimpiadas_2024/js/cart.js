$(document).ready(function() {
    $.ajax({
        url     : 'modules/fetch_cart.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablecart").html(resp);
        },
        error   : function(resp){
        }  
    });
});

function addtoCart(idproducto, idusuario){
        Swal.fire({
          title: "¿Agregar este producto al carrito?",
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
              type:"post",
              url:"modules/addtocart.php",
              data: { idprod : idproducto,
                      idusuario : idusuario  
                    },
              success:function(response){
                if(response == 'OK'){
                Swal.fire("¡Agregado!", "", "success");
              } else{
                console.log(response);
              }}
          });
          }
        });
      }

function volver(){
    window.location.href = "index.php";
}

function remove(iduser, idprod){
          $.ajax({
            type:"post",
            url:"modules/delete_fromcart.php",
            data: { delete : idprod,
                delete2 : iduser
            },
            success:function(data){
              Swal.fire("¡Eliminado!", "", "success");
              location.reload();
            }
        })
    }

function pedido(idpedido, total){
    $.ajax({
        type:"post",
        url:"modules/set_pedido.php",
        data: { idpedido : idpedido,
            total : total
        },
        success:function(data){
           console.log(data);
          Swal.fire("¡Pedido realizado!", "", "success");
          location.href = "pedidos.php";
        }
    })
}
