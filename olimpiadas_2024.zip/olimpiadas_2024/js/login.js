function ansValidation(ev) {
    let isFormValid = $('#form')[0].checkValidity();
   if(!isFormValid) {
        $('#form').reportValidity();
    } else{
        ev.preventDefault();
    var email = document.getElementById('email').value;
    var contrasena = document.getElementById('password').value;
const data = {
  email: email,
  contrasena: contrasena
};

$.ajax({
    type: 'POST',
    url: "modules/login_module.php",
    data: data,
    success: function(response){
        console.log(response);
        if(response == "Email no encontrado"){
        Swal.fire({
            title: "Email no encontrado",
            text: "Debe registrarse para iniciar sesión",
            footer: '<a href="register.php">Registrarse</a>',
            confirmButtonText: "OK"
          })
} 
        if (response == "Su usuario no está verificado"){
            Swal.fire({
                title: "Su usuario no está verificado",
                text: "Debe verificar su usuario para ingresar",
                footer: '<a href="gmail.com">Abrir Gmail</a>',
                confirmButtonText: "OK"
            })
        } 
        if (response == "Contrasena incorrecta"){
            Swal.fire({
                title: "Contraseña incorrecta",
                text: "Su contraseña no coincide con el mail indicado",
                footer: '<a href="forgot.php">Olvidé mi contraseña</a>',
                confirmButtonText: "OK"
              })
        }
        if (response == "Sesión iniciada"){
            location.href = "index.php";
}
}})
}}