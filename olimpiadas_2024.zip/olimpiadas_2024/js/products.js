$(document).ready(function() {
    $.ajax({
        url     : 'modules/fetch_products_admin.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablebody").html(resp);
        },
        error   : function(resp){
        }  
    });
});


function ansValidation(ev){
let isFormValid = $('#form')[0].checkValidity();
   if(!isFormValid) {
        $('#form').reportValidity();
    } else{
        ev.preventDefault();
var nombre = document.getElementById('titulo').value;
var descripcion = document.getElementById('descripcion').value;
var precio = document.getElementById('precio').value;
const data = {
  nombre: nombre,
  descripcion: descripcion,
  precio: precio
};
$.ajax({
    type: 'POST',
    url: "modules/add_products.php",
    data: data,
    success: function(response){
       if(response == "OK"){
        Swal.fire({
            title: "Producto subido",
            confirmButtonText: "OK"
          }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
}})
} else{
    Swal.fire({
        title: "Producto ya registrado",
        text: "Ese producto ya se encuentra en la base de datos",
        confirmButtonText: "OK"
      })
}

}})
}}

function myDelete(deleteid){
    Swal.fire({
      title: "¿Está seguro de eliminar este producto?",
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonText: "Eliminar",
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          type:"post",
          url:"modules/delete_products.php",
          data: { delete : deleteid},
          success:function(data){
            location.reload();
            Swal.fire("¡Eliminado!", "", "success");
          }
      });
      } else if (result.isDenied) {
        Swal.fire("No se eliminó el producto", "", "info");
      }
    });
  }
  function myModify(modifyid){
    $.ajax({
        url     : 'modules/edit_products_admin.php',
        data    : {id:modifyid},
        type    : 'GET',
        success : function(resp){
            Swal.fire({
                title: "Edición de producto",
                html: resp,
                confirmButtonText: "OK"
              }) .then((result) => {
                if (result.isConfirmed) {
                    var edit_titulo = document.getElementById('edit_titulo').value;
                    var edit_descripcion = document.getElementById('edit_descripcion').value;
                    var edit_precio = document.getElementById('edit_precio').value;
                    const data1 = {
                        id: modifyid,
                        nombre: edit_titulo,
                        descripcion: edit_descripcion,
                        precio: edit_precio
                      };
                      
                    $.ajax({
                        type: 'POST',
                        url: "modules/edit_products_add.php",
                        data: data1,
                        success: function(response){
                            console.log(response);
                           if(response == "OK"){
                            Swal.fire({
                                title: "Producto editado",
                                confirmButtonText: "OK"
                              }).then((result) => {
                                if (result.isConfirmed) {
                                    location.reload();
                    }})
                    } else{
                        Swal.fire({
                            title: "Producto ya registrado",
                            text: "Ese producto ya se encuentra en la base de datos",
                            confirmButtonText: "OK"
                          })
                    }
                    
                    }})
              }
        } 
              )}
  }) 
}
