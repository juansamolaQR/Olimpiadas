<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="styles/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   </head>
<body>
  <div class="wrapper">
    <h2>Iniciar sesión</h2>
    <form id="form" name="form">
      <div class="input-box">
        <input type="email" id="email" name="email" placeholder="Ingresar email" required>
      </div>
      <div class="input-box">
        <input type="password" id="password" name="password" placeholder="Ingresar contraseña" required>
      </div>
      <div class="input-box button">
        <input type="submit" onClick="ansValidation(event)" value="Iniciar sesión">
      </div>
      <div class="text">
        <h3>¿No tienes una cuenta? <a href="register.php">Registrarse</a></h3>
      </div>
    </form>
  </div>
        <script src="js/jquery.js"></script>
        <script src="js/login.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
</body>
</html>